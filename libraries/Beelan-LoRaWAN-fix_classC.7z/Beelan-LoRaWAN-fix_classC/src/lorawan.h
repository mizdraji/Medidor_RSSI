#ifndef _LORAWAN_H_
#define _LORAWAN_H_

#include "arduino-rfm/lorawan-arduino-rfm.h"

extern LoRaWANClass lora;

#endif